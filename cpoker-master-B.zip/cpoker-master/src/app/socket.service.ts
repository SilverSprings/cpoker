import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SocketService {

  constructor(){}
	socket = io();

	joinRoom(player) {
		this.socket.emit('joinroom', player);
	}
	
	playersUpdate() {
		let obs = new Observable(observer => {
			this.socket.on('playersupdate', (players) => observer.next(players));
		});
		return obs;
	}

	realPlayersUpdate() {
		let obs = new Observable(observer => {
			this.socket.on('realplayersupdate', (players) => observer.next(players));
		});
		return obs;
	}
	
	cardsDealt() {
		let obs = new Observable(observer => {
			this.socket.on('cardsdealt', (cards) => observer.next(cards));
		});
		return obs;
	}
	
	showResults() {
		let obs = new Observable(observer => {
			this.socket.on('showresults', (sdComplete) => observer.next(sdComplete));
		});
		return obs;
	}
	
	leaveBeforeGameStart(player) {
		this.socket.emit('leavebeforegamestart', player);
	}

	leaveAfterGameStart(player) {
		this.socket.emit('leaveaftergamestart', player);
	}
	
	playerSD(player) {
		this.socket.emit('playerSD', player);
	}	

}
