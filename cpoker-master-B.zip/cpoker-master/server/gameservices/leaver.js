var leavershowdown = function leaver(player) {
	// return a blank object showdown with some initialisation
    var defCard = {s:"x",v:-1,img:"assets/defaultcard.png"}
	var tempHand = {	
		hPlayerId:player.pId,
		hPlayerName:player.pName,
		hF:{hand:[], type:'leaver', value:-1, subvalue:-1},
		hM:{hand:[], type:'leaver', value:-1, subvalue:-1},	
		hL:{hand:[], type:'leaver', value:-1, subvalue:-1}
	};
	tempHand.hF.hand.push(defCard, defCard, defCard );
	tempHand.hM.hand.push(defCard, defCard, defCard, defCard, defCard );
	tempHand.hL.hand.push(defCard, defCard, defCard, defCard, defCard );	
	return tempHand;
}

module.exports = leavershowdown;