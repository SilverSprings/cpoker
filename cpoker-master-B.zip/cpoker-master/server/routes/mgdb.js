//standard acces to mongoDB documents
/*
The database 'game' is composed of 3 collections
	db.collection('players'); --> dynamic document creation
	db.collection('rooms'); --> non dynamic : the room must exist before
	db.collection('showdowns'); --> non dynamic : the showdown must exist before

the statements to select/update/create/delete documents :

from roomsio.js :
  mgdb.retrieveRoom
  mgdb.initShowdown	
  mgdb.gameInProgressRoomChange
  mgdb.retrievePlayerNamesFromRoom
  mgdb.addHandShowdown
  mgdb.playerShowdown
  mgdb.retrieveShowdown
  mgdb.completeShowdown
  
from api.js :
  mgdb.addPlayer
  mgdb.availableRooms
  mgdb.addPlayerInRoom
  mgdb.addRoomInPlayer
  mgdb.removePlayerInRoom
  mgdb.removeRoomInPlayer
*/
var Rx = require('rx');

/* --------------------- */
/*         FIND          */
/* --------------------- */ 
//retrieveRoom
exports.retrieveRoom = (db, rId) => {
	return db.collection('rooms').findOne( 
		{rId : rId}, 
		null,
		(err, room) => {
			if (err) {
				console.log('MGDB : error occured when retrieving room '+err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : room retrieved' + room);
				return Rx.Observable.of(room);}
		}
	);
}

exports.availableRooms = (db) => {
	return db.collections('rooms').find( 
		{ $and: [{rSeats: { $lt:4}},{rGameInProgress:false}] },
		(err, rooms) => {
			if (err) {
				console.log('MGDB : error occured when retrieving availables rooms '+err);
				return Rx.Observable.of(false);}	
			else {
				console.log('MGDB : rooms retrieved' + rooms);
				return Rx.Observable.of(rooms);}
		}
	);
}

exports.retrievePlayerNamesFromRoom = (db, roomString) => {
	return db.collections('players').find( 
		{ pRoom = roomString },
		(err, players) => {
			if (err) {
				console.log('MGDB : error occured when retrieving players from a room '+err);
				return Rx.Observable.of(false);}	
			else {
				console.log('MGDB : playerss retrieved from a room' + players);
				return Rx.Observable.of(players);}
		}
	);
}

exports.retrieveShowdown = (db, player) => {
	return db.collection('showdowns').findOne(
		{ sRoom = player.pRoom},
		null,
		(err, sd) => {
			if (err) {
				console.log('MGDB : error occured when retrieving showdown '+err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : showdown retrieved' + sd);
				return Rx.Observable.of(sd);}
		}		
	);
}

exports.retrievePlayer = (db, playerString) => {
	return db.collection('players').findOne( 
		{pId : playerString}, 
		null,
		(err, player) => {
			if (err) {
				console.log('MGDB : error occured when retrieving player '+err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : player retrieved' + player);
				return Rx.Observable.of(player);}
		}
	);
}

/* --------------------- */
/*        INSERT         */
/* --------------------- */ 
//addPlayer
exports.addPlayer = (db, player) => {
	return db.collection('players').insertOne(
		player, 
		(err, result) => {
			if (err)  {
				console.log('MGDB : error occured when adding player :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : player added' + result);
				return Rx.Observable.of(true);}
		}
	);	
}

/* --------------------- */
/*        DELETE         */
/* --------------------- */ 
//deletePlayer
exports.deletePlayer = (db, pId) => {		
	return db.collection('players').deleteOne( 
		{pId : pId},
		(err, result) => {
			if (err)  {
				console.log('MGDB : error occured when deleting player :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : player deleted' + result);
				return Rx.Observable.of(true);}	
		}
	);
}





/* --------------------- */
/*        UPDATE         */
/* --------------------- */ 
//addPlayerInRoom
exports.addPlayerInRoom = (db, roomPlayer) => {		
	return db.collection('rooms').updateOne( 
		{rId : RoomPlayer.rId},
		{$push : {rPlayers : roomPlayer.pId }, $inc : { rSeats : 1}}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when adding a player in a room :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : player added to a room' + result);
				return Rx.Observable.of(true);}
		}
	);		
}

//addRoomInPlayer
exports.addRoomInPlayer = (db, roomPlayer) => {
	return db.collection('players').updateOne( 
		{pId : roomPlayer.pId},
		{$set : {pRoom : roomPlayer.rId}}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when adding a room in a player :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : room added to a player' + result);
				return Rx.Observable.of(true);}
		}		
	);
}

//removePlayerInRoom
exports.removePlayerInRoom = (db, player) => {
	return db.collection('rooms').updateOne( 
		{rId : player.pRoom},
		{$pull : {rPlayers : player.pId }, $inc : { rSeats : -1}}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when removing a player in a room :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : player removed from a room' + result);
				return Rx.Observable.of(true);}
		}
	);
}

//initRoom
exports.initRoom = (db, roomString) => {
	return db.collection('rooms').updateOne( 
		{rId : roomString},
		{$set {rPlayers : [], rSeats:0, rGameInProgress:false }}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when removing a player in a room :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : player removed from a room' + result);
				return Rx.Observable.of(true);}
		}
	);
}

//removeRoomInPlayer
exports.removeRoomInPlayer = (db, player) => {
	return db.collection('players').updateOne(	
		{pId : player.pId},
		{$set : {pRoom : '', pSD:false}}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when removing a room in a player :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : room removed from a player' + result);
				return Rx.Observable.of(true);}
		}
	);
}

//initShowdown
exports.initShowdown = (db, sd) => {
	return db.collection('showdowns').updateOne(
		{ sRoom : sd.sRoom},
		{ $set : {sHands:sd.sHands, sWinnerF:sd.sWinnerF, sWinnerM:sd.sWinnerM, sWinnerL:sd.sWinnerL, sScooper:sd.sScooper }}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when initializing showdown :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : showdown initialized' + result);
				return Rx.Observable.of(true);}
		}
	);		
}

//gameInProgressRoomChange
exports.gameInProgressRoomChange = (db, roomString, bool) => {
	return db.collection('rooms').updateOne(
		{ rId : roomString},
		{ $set : {rGameInProgress:bool}},
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when changing rGameInProgress :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : rGameInProgress changed to : '+bool ' : '+ result);
				return Rx.Observable.of(true);}
		}		
	);
}

//addHandShowdown
exports.addHandShowdown = (db, player, hand) => {
	return db.collection('showdowns').updateOne(
		{sRoom:player.pRoom},
		{$push : {sHands : hand }},
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when adding a hand to showdown :'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : hand added to showdown : '+ result);
				return Rx.Observable.of(true);}
		}		
	);		
}

//playerShowdown
exports.playerShowdown = (db, player, bool) => {
	return db.collection('players').updateOne(	
		{pId : player.pId},
		{$set : {pSD:bool}}, 
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when changing pSD :'+ bool + ': 'err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : room removed from a player' + result);
				return Rx.Observable.of(true);}
		}
	);
}

//completeShowdown
exports.completeShowdown = (db, sd) => {
	return db.collection('showdowns').updateOne(
		{sRoom:sd.sRoom},
		{$set : {sWinnerF:sd.sWinnerF,sWinnerM:sd.sWinnerM,sWinnerL:sd.sWinnerL, sScooper:sd.sScooper }},
		(err, result) => { 
			if (err) {
				console.log('MGDB : error occured when showdown completed:'+ err);
				return Rx.Observable.of(false);}
			else {
				console.log('MGDB : showdown completed : '+ result);
				return Rx.Observable.of(true);}
		}		
	);		
}