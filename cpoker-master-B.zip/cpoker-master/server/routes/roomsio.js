//gameservices - homebrew modules
var deck = require('../gameservices/deck');
var newshowdown = require('../gameservices/newshowdown');
var computeshowdown = require('../gameservices/showdownresults');
var leaverhand = require('../gameservices/leaver');
//router
var mgdb = require('./mgdb');


var socketPlayerArray = [];

var roomconnect = (db, io) => {

	io.on('connection', (socket) => {
		console.log('somebody is connected - socket.id:'+socket.id);

		// LISTEN : a player has entered a room
		socket.on('joinroom', (player) => {	
			socket.join(player.pRoom);
			socketPlayerArray.push({skId:socket.id, pId:player.pId});
			mgdb.retrieveRoom(db, player.pRoom).subscribe( room => {
				console.log('joinroom :'+room);
				// if all seats are taken in the room, and a game is not in progress, a new deck is required				
				if (room.rSeats == 4 && room.rGameInProgress == false) {
					// initilialize the showdown record
					var tempshowdown = newshowdown(room.rId);
					mgdb.initShowdown(db, tempshowdown).subscribe(done => {
						console.log('showdown added : ', done);
					});
					// change GameInProgress to true 
					mgdb.gameInProgressRoomChange(db, room.rId, true).subscribe(done => {
						console.log('GameInProgress : ', done);
						// retrieve the players from a room
						mgdb.retrievePlayerNamesFromRoom(db, room.rId).subscribe( cursor => {
							cursor.toArray((err, players) => {
								if (err) console.log('an error occured while toArray '+err);
								console.log('find all players in a room ok');
								// EMIT : tell the room a player is coming in
								io.to(room.rId).emit('realplayersupdate', players);						
							});
						});		
						//a new deck is delivered, every hand are dedicated to a player
						var tempDeck = deck(room);
						for(var _p = 0; _p < 4; _p++) {
							var socketPlayer =  socketPlayerArray.find( sp => sp.pId === tempDeck.dHands[_p].hPlayer);
							//EMIT : give to each player their assigned cards
							io.to(socketPlayer.skId).emit('cardsdealt',tempDeck.dHands[_p].hCards );						
						}						
					});					
				}
				else {
					// retrieve the players from a room
					mgdb.retrievePlayerNamesFromRoom(db, room.rId).subscribe( cursor => {
						cursor.toArray((err, players) => {
							if (err) console.log('an error occured while toArray '+err);
							console.log('find all players in a room ok');
							// EMIT : tell the room a player is coming in
							io.to(room.rId).emit('playersupdate', players);						
						});
					});	
				}
			});
		});
		
	
		// LISTEN : a player is ready to showdown
		socket.on('playerSD', (player) => {
			var hand = {hPlayerId:player.pId, 
					   hPlayerName:player.pName, 
					   hF:player.pCardsSorted.hF,
					   hM:player.pCardsSorted.hM,
					   hL:player.pCardsSorted.hL};
			// add the hand of the player to the showdown record
			mgdb.addHandShowdown(db, player, hand).subscribe(done => { 
				console.log('addHandShowdown : ', done);
			});
			// change the player boolean SD in the mongoDB 
			mgdb.playerShowdown(db, player, true).subscribe(done => {
				console.log('playerShowdown : ', done);
			});
			// retrieve all the players
			mgdb.retrievePlayerNamesFromRoom(db, player.pRoom).subscribe( cursor => {
				cursor.toArray((err, players) => {
					if (err) console.log('an error occured while toArray '+err);
					console.log('find all players in a room ok');
					// if everybody is ready to showdown
					if (players.every( p => p.pSD === true)) {
						// calculate the results of the showdown
						mgdb.retrieveShowdown(db, player).subscribe( sd => {
							var sdComplete = computeshowdown(sd);
							mgdb.completeShowdown(sdComplete).subscribe( done = > {
								console.log('Updating showdown : ' done);
								// EMIT : tell the room results are ready
								io.to(player.pRoom).emit('showresults',sdComplete);
							});
						});
						// reset the room
						mgdb.initRoom(db, player.pRoom).subscribe(done => {						
							console.log('Init room :', done);
						});
						// reset each players room
						players.forEach( player => {
							mgdb.removeRoomInPlayer(db, player).subscribe( done => {						
								console.log('Remove room in player done :', done);
							});
						});
					} 
					else {
						// EMIT : tell the room the players ready to showdown
						io.to(player.pRoom).emit('playersupdate', players);						
					}
				});
			});											
		});

/*---------------------------------------------------------------------------------------------------*/
		
		// LISTEN : a player has left a room before the game has started
		socket.on('leavebeforegamestart', (player) => {
			socket.leave(player.pRoom);
			mgdb.removePlayerInRoom(db, player).subscribe( done => {						
				console.log('Remove player in room done :', done);
			});
			mgdb.removeRoomInPlayer(db, player).subscribe( done => {						
				console.log('Remove room in player done :', done);
				mgdb.retrievePlayerNamesFromRoom(db, player.pRoom).subscribe( cursor => {
					cursor.toArray((err, players) => {
						if (err) console.log('an error occured while toArray '+err);
						console.log('find all players in a room ok');					
						// EMIT : tell the room somebody has left
						io.to(player.pRoom).emit('playersupdate', players);
						});
				});
			});	
		});

		// LISTEN : a player has left the room after the game has started
		socket.on('leaveaftergamestart', (player) => {
			socket.leave(player.pRoom);
			var hand = leaverhand(player);
			// add the hand of the player to the showdown record
			mgdb.addHandShowdown(db, player, hand).subscribe(done => { 
				console.log('addHandShowdown : ', done);
			});			
			mgdb.removePlayerInRoom(db, player).subscribe( done => {						
				console.log('Remove player in room done :', done);
			});
			mgdb.removeRoomInPlayer(db, player).subscribe( done => {						
				console.log('Remove room in player done :', done);
				mgdb.retrievePlayerNamesFromRoom(db, player.pRoom).subscribe( cursor => {
					cursor.toArray((err, players) => {
						if (err) console.log('an error occured while toArray '+err);
						console.log('find all players in a room ok');					
						// EMIT : tell the room somebody has left
						io.to(player.pRoom).emit('playersupdate', players);
						});
				});
			});	
		});		
		
		// LISTEN : a player disconnection
		socket.on('disconnect', () => {
			console.log('somebody is disconnected - socket.id:'+socket.id);
		   //brutal disconnection : clean up everything
		   var playerDC = socketPlayerArray.find( sp => sp.skId === socket.id);
		   var indexPlayerDC = = socketPlayerArray.findIndex( sp => sp.skId === socket.id);
		   socketPlayerArray.splice(indexPlayerDC, 1);
		   if (playerDC !== undefined) { 
				console.log(playerDC.pId+' whose socket.id is'+ playerDC.skId +'is disconnected');
				mgdb.retrievePlayer(db, playerDC.pId).subscribe( playerMGDB => {
					mgdb.retrieveRoom(db, playerMGDB.pRoom).subscribe( roomMGDB => {
						if (roomMGDB.rGameInProgress === true) {
							var hand = leaverhand(playerMGDB);
							// add the hand of the player to the showdown record
							mgdb.addHandShowdown(db, playerMGDB, hand).subscribe(done => { 
								console.log('addHandShowdown : ', done);
							});								
						}
					});
					mgdb.removePlayerInRoom(db, playerMGDB).subscribe( done => {						
						console.log('Remove player in room done :', done);
						mgdb.retrievePlayerNamesFromRoom(db, playerMGDB.pRoom).subscribe( cursor => {
							cursor.toArray((err, players) => {
								if (err) console.log('an error occured while toArray '+err);
								console.log('find all players in a room ok');					
								// EMIT : tell the room somebody has left
								io.to(playerMGDB.pRoom).emit('playersupdate', players);
							});
						});
					});	
					mgdb.deletePlayer(db, playerMGDB.pId).subscribe( done => {						
						console.log('Delete player done :', done);
					});		
				});					
			}				
		});	
	});
}
module.exports = roomconnect;