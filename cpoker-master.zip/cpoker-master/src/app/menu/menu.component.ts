import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  constructor(private roomService: RoomService) { }
  
  player:any;
  gameCPUInProgress:boolean;
  gameInProgress:boolean;
  rulesHidden:boolean;
  registeredPlayer:boolean;
  chooseAnotherRoom:boolean;
  nameNotEntered:boolean;
  rooms:any;
  roomSelected;
  room;
  
  ngOnInit() {
	this.gameCPUInProgress = false;
    this.gameInProgress = false;
	this.registeredPlayer = false;
	this.nameNotEntered = true;
	this.rulesHidden = false;
	this.chooseAnotherRoom = false;
    this.player = {	pId:'',
					pRoom:'',
					pName:'',
					pSD:false
	};	  
  }
  
  registerPlayer(inputPlayerName : string) {
	this.player.pName = inputPlayerName; 
	this.roomService.availableRooms().subscribe(rooms => this.rooms = rooms);	
	this.registeredPlayer = true;
  }
  
  checkName(inputPlayerName : string) {
	var stringInspect = inputPlayerName.trim();
	if (stringInspect != '') this.nameNotEntered = false;
	if (stringInspect == '') this.nameNotEntered = true;	
  }
  
  chooseAnotherRoomtoFalse() {
	this.chooseAnotherRoom = false;
  }
  
  startGameCPU() {
	this.gameCPUInProgress = true;
  }

  startGame() {
	this.roomService.retrieveRoom(this.roomSelected.rId).subscribe( room => {
		if (room.rSeats < 4 && room.rGameInProgress == false ) {
			this.player.pRoom = room.rId;
			this.roomService.addPlayer(this.player).subscribe( player => {
				this.player = player;
				this.roomService.addPlayerInRoom(this.player).subscribe(result => {
					console.log('the player was added to the room :'result)
					this.gameInProgress = true;
				});
			});
		} else {
			this.chooseAnotherRoom = true;
			this.roomService.availableRooms().subscribe(rooms => this.rooms = rooms);			
		}
	});
  }
  
  endGameCPU() {
	this.gameCPUInProgress = false;	
  }
  
  endGame() {
	this.roomService.availableRooms().subscribe(rooms => this.rooms = rooms);
	this.gameCPUInProgress = false;	
  }
  
  showRules() {
	this.rulesHidden = false;
  }
  
  hideRules() {
	this.rulesHidden = true;
  }  
  
}
