import { Component, Input, OnInit, EventEmitter, Output  } from '@angular/core';
import { RankerService } from '../ranker.service';

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {

  @Output() doneSorting = new EventEmitter<any>();
  
  @Input() player:any; /* what player looks like : 
  {
		pId:'PLAYER_HUMAN',
		pRoom:'BOTROOM',
		pName:'Brandon',
		pSD:false,
		pCardsDealt:[{s:"d",v:10,img:"assets/10D.png"},
					 {s:"s",v:12,img:"assets/12S.png"},
					 {s:"d",v:8,img:"assets/8D.png"},
					 {s:"h",v:8,img:"assets/8H.png"},
					 {s:"h",v:2,img:"assets/2H.png"},
					 ...
					 {s:"d",v:7,img:"assets/7D.png"}] 
  }  
  */    
  //handPlayed hold the reference of the cards that the player has placed.  
  fh_played = {hand:[]};
  mh_played = {hand:[]};
  lh_played = {hand:[]}; 
  handDealt;

  counterCardsSelected:int;
  //messages for each hand
  fh_msg:string;
  mh_msg:string;
  lh_msg:string;
  
  //activate/deactivate buttons
  fnotAvail:boolean;
  mnotAvail:boolean;
  lnotAvail:boolean;
  fnotFill:boolean;
  mnotFill:boolean;
  lnotFill:boolean;
  sdnotReady:boolean;
  
  handFinal = {hF:{},hM:{},hL:{}};
  /*{
	 hF:{hand:[...], type:'One Pair', value:1, subvalue:1141404},
	 hM:{hand:[...], type:'Straight', value:4, subvalue:40908070605},	
	 hL:{hand:[...], type:'Straight Flush',	value:8, subvalue:40908070605}	
    } */  


  constructor(private rankerService: RankerService) { }

  ngOnInit() {
	console.log('hand dealt to the player', this.player.pCardsDealt);
	this.handDealt = this.player.pCardsDealt.map( c => {
		c['selected'] = false;
		c['img'] = 'assets/' + c.v + c.s.toUpperCase() + '.png';
		return c;		
	}
	this.fh_msg='';
	this.mh_msg='';
	this.lh_msg='';
	this.counterCardsSelected = 0;		
	this.sdnotReady = true;	
	this.fnotAvail=true;
	this.mnotAvail=true;
	this.lnotAvail=true;
	this.fnotFill=true;
	this.mnotFill=true;
	this.lnotFill=true;	
  }
  
  sortRank() {
	this.handDealt.sort( (a, b) => {return a.v - b.v});
  }
  
  sortSuit() {
	this.handDealt.sort( (a, b) => {return a.v - b.v});
	this.handDealt.sort( (a, b) => {
		if (a.s < b.s) return -1;
		if (a.s > b.s) return 1;
		if (a.s = b.s) return 0; 
	});
  }
  
  cardClickedHD(i) {
	if (this.handDealt[i].selected == false) {
		if (this.counterCardsSelected != 5) {
			this.handDealt[i].selected = true;
			this.counterCardsSelected++;
		}
	} else {
		this.handDealt[i].selected = false;
		this.counterCardsSelected--;
	}
	this.activateButtons();
  }
  
  feed(handToFeed) {
	if (handToFeed == 'DH_FH') {
		this.fh_played.hand = this.fh_played.hand.concat(this.handDealt.filter(c => c.selected == true));
		this.handDealt = this.handDealt.filter(c => c.selected == false);
		if (this.fh_played.hand.length == 3) {
			this.handFinal.hF = this.checkHand(this.fh_played.hand);
			this.fh_msg = '' + this.handFinal.hF.type;
		}
	}
	if (handToFeed == 'DH_MH') {
		this.mh_played.hand = this.mh_played.hand.concat(this.handDealt.filter(c => c.selected == true));
		this.handDealt = this.handDealt.filter(c => c.selected == false);	
		if (this.mh_played.hand.length == 5) {
			this.handFinal.hM = this.checkHand(this.mh_played.hand);
			this.mh_msg = '' + this.handFinal.hM.type;	
		}
	}
	if (handToFeed == 'DH_LH') {
		this.lh_played.hand = this.lh_played.hand.concat(this.handDealt.filter(c => c.selected == true));
		this.handDealt = this.handDealt.filter(c => c.selected == false);		
		if (this.lh_played.hand.length == 5) {			
			this.handFinal.hL = this.checkHand(this.lh_played.hand);
			this.lh_msg = '' + this.handFinal.hL.type;	
		}
	}
	this.counterCardsSelected = 0;	
	this.activateButtons();
	this.evaluateMessage();
  }

  cardClickedRemove(handToDelete, card, i) {
	card.selected = false;
	this.handDealt.push(card);
	if (handToDelete == 'FH') {
		this.fh_played.hand.splice(i,1);
	}
	if (handToDelete == 'MH') {
		this.mh_played.hand.splice(i,1);
	}
	if (handToDelete == 'LH') {
		this.lh_played.hand.splice(i,1);
	}
	this.activateButtons();
	this.evaluateMessage();	
  }

  undo(handToUndo) {
	if (handToUndo == 'FH') {
		this.fh_played.hand.forEach( c => c.selected = false);
		this.handDealt = this.handDealt.concat(this.fh_played.hand);
		this.fh_played.hand = [];
	}
	if (handToUndo == 'MH') {
		this.mh_played.hand.forEach( c => c.selected = false);
		this.handDealt = this.handDealt.concat(this.mh_played.hand);
		this.mh_played.hand = [];	
	}
	if (handToUndo == 'LH') {
		this.lh_played.hand.forEach( c => c.selected = false);
		this.handDealt = this.handDealt.concat(this.lh_played.hand);
		this.lh_played.hand = [];	
	}
	this.activateButtons();
	this.evaluateMessage();		
  }
  
  showdown () {
	this.doneSorting.emit(this.handFinal);
  } 
  
  activateButtons() {
	if (this.fh_played.hand.length == 3 && this.mh_played.hand.length == 5 && this.lh_played.hand.length == 5) 
		 {this.sdnotReady = false;}
	else {this.sdnotReady = true;}
	if (this.fh_played.hand.length != 0) {this.fnotFill = false} else {this.fnotFill = true}
	if (this.mh_played.hand.length != 0) {this.mnotFill = false} else {this.mnotFill = true}
	if (this.lh_played.hand.length != 0) {this.lnotFill = false} else {this.lnotFill = true}
	this.fnotAvail=true;
	this.mnotAvail=true;
	this.lnotAvail=true;	
	if (this.counterCardsSelected != 0) {
		if (this.fh_played.hand.length==0 && counterCardsSelected <= 3) this.fnotAvail = false;
		if (this.fh_played.hand.length==1 && counterCardsSelected <= 2) this.fnotAvail = false;
		if (this.fh_played.hand.length==2 && counterCardsSelected == 1) this.fnotAvail = false;	

		if (this.mh_played.hand.length==0 && counterCardsSelected <= 5) this.mnotAvail = false;
		if (this.mh_played.hand.length==1 && counterCardsSelected <= 4) this.mnotAvail = false;
		if (this.mh_played.hand.length==2 && counterCardsSelected <= 3) this.mnotAvail = false;
		if (this.mh_played.hand.length==3 && counterCardsSelected <= 2) this.mnotAvail = false;
		if (this.mh_played.hand.length==4 && counterCardsSelected == 1) this.mnotAvail = false;

		if (this.lh_played.hand.length==0 && counterCardsSelected <= 5) this.lnotAvail = false;
		if (this.lh_played.hand.length==1 && counterCardsSelected <= 4) this.lnotAvail = false;
		if (this.lh_played.hand.length==2 && counterCardsSelected <= 3) this.lnotAvail = false;
		if (this.lh_played.hand.length==3 && counterCardsSelected <= 2) this.lnotAvail = false;
		if (this.lh_played.hand.length==4 && counterCardsSelected == 1) this.lnotAvail = false;
	}	
  }  

  evaluateMessage() {
	if (this.fh_played.hand.length == 3 && this.mh_played.hand.length == 5) {
		if (this.fh_played.subvalue > this.mh_played.subvalue) this.fh_msg = 'First hand better than Middle hand !';
	}
	if (this.mh_played.hand.length == 5 && this.lh_played.hand.length == 5) {
		if (this.mh_played.subvalue > this.lh_played.subvalue) this.mh_msg = 'Middle hand better than Last hand !';
	}	
  	if (this.fh_played.hand.length < 3) this.fh_msg = '';
	if (this.lh_played.hand.length < 5) this.lh_msg = '';
	if (this.mh_played.hand.length < 5) this.mh_msg = '';
  } 
  
  checkHand(handCk) {
	console.log ('checkHand', hand);
	var tempHandMini = handCk.map( card => {return {s:card.s, v:card.v};}) ;
	var tempHand = this.rankerService.bestHand(tempHandMini);
	return tempHand;		
  }  
}