import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.css']
})
export class ResultsComponent implements OnInit {
  @Input() sd:any; /* What sd looks like :
{ sHands: [{	hPlayerId:'PLAYER_HUMAN'
				hPlayerName:'Brandon'
				hF:{hand:[...], type:'One Pair', value:1, subvalue:1141404},
				hM:{hand:[...], type:'Straight', value:4, subvalue:40908070605},	
				hL:{hand:[...], type:'Straight Flush',	value:8, subvalue:80908070605}	
			},
		   {	hPlayerId:'PLAYER_BOTLEFT'
				hPlayerName:'left bot'
				hF:{hand:[...], type:'One Pair', value:1, subvalue:1141404},
				hM:{hand:[...], type:'Two Pairs', value:2, subvalue:21010090905},	
				hL:{hand:[...], type:'Full House',	value:6, subvalue:60808080606}	
		   },...],
  sRoom: 'ROOM_BOTROOM',
  sWinnerF:{winners:['PLAYER_adada'],type:'High Card'},
  sWinnerM:'',
  sWinnerL:'',
  sScooper:''  
} */  
  @Output() endGameNow = new EventEmitter<any>();

  
  constructor() { }
  
  gameSummaryByHand = {fp0:boolean,fp1:boolean,fp2:boolean,fp3:boolean,
					   mp0:boolean,mp1:boolean,mp2:boolean,mp3:boolean,
					   lp0:boolean,lp1:boolean,lp2:boolean,lp3:boolean};

  firstMessageResults = '';
  middleMessageResults = '';
  lastMessageResults = '';  
  
  player1Message = '';
  player2Message = '';
  player3Message = '';
  player4Message = '';
  
  misset = {p0=false,p1=false,p2=false,p3=false};

  leaver = {p0=false,p1=false,p2=false,p3=false};
  
  ngOnInit() {
	
	for (var _p=0; _p < 4; _p++) {
		if (this.sd.sHands[_p].hF.type = 'mis-set') misset['p'+_p]=true;
		if (this.sd.sHands[_p].hF.type = 'leaver') leaver['p'+_p]=true;	
	}
	this.gameSummaryByHand = {fp0:false,fp1:false,fp2:false,fp3:false,
							  mp0:false,mp1:false,mp2:false,mp3:false,
							  lp0:false,lp1:false,lp2:false,lp3:false};
	
	//determines the fp0/fp1/fp2/fp3 and the result message for the first hand
	var fWinnersName = this.getWinnerAndBoolean('f',this.sd.sWinnerF.winners) ;
	this.firstMessageResults = clearlyStateWinner(fWinnersName, this.sd.sWinnerF.type);

	//determines the mp0/mp1/mp2/mp3 and the result message for the middle hand
	var mWinnersName = this.getWinnerAndBoolean('m',this.sd.sWinnerM.winners) ;
	this.middleMessageResults = clearlyStateWinner(mWinnersName, this.sd.sWinnerM.type);	

	//determines the lp0/lp1/lp2/lp3 and the result message for the last hand
	var lWinnersName = this.getWinnerAndBoolean('l',this.sd.sWinnerL.winners) ;
	this.lastMessageResults = clearlyStateWinner(lWinnersName, this.sd.sWinnerL.type);	
  }

  endGame() {
	this.endGameNow.emit();
  }
  
  getWinnerAndBoolean(FML, winners) {
    var tempWinnersNames = []
	winners.forEach(w => {
		for (var _p=0; _p <4; _p++) {
			if (w == this.sd.sHands[_p].hPlayerId) {
				this.gameSummaryByHand[''+FML+'p'+_p] = true;
				tempWinnersNames.push(this.sd.sHands[_p].hPlayerName);
			}
		}
	});
	return tempWinnersNames;
  }
}

function clearlyStateWinner(winnerNames, type ) {
	switch (winnerNames.length) {
		case 1 : return 'Winner : '+winnerNames[0]+' with '+type ;
		case 2 : return 'Tie between : '+winnerNames[0]+' and '+winnerNames[1]+' with '+type ;	
		case 3 : return 'Tie between : '+winnerNames[0]+', '+winnerNames[1]+' and '+winnerNames[2] +' with '+type ;		
		case 4 : return 'Tie between : '+winnerNames[0]+', '+winnerNames[1]+', '+winnerNames[2]+' and '+winnerNames[3] +' with '+type ;	
	}
}