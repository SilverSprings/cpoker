import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { SocketService } from '../room.service';

@Component({
  selector: 'app-cityroom',
  templateUrl: './cityroom.component.html',
  styleUrls: ['./cityroom.component.css']
})
export class CityroomComponent implements OnInit {

  constructor(private socketService:SocketService, private cardService:CardService) { }

  @Input() player; /* what player looks like
  {
		pId:'PLAYER_HUMAN',
		pRoom:'BOTROOM',
		pName:'Brandon',
		pSD:false,
		--> when everybody join the room :
		pCardsDealt:[{s:"d",v:10,img:"assets/10D.png"},
					 {s:"s",v:12,img:"assets/12S.png"},
					 {s:"d",v:8,img:"assets/8D.png"},
					 {s:"h",v:8,img:"assets/8H.png"},
					 {s:"h",v:2,img:"assets/2H.png"},
					 ...
					 {s:"d",v:7,img:"assets/7D.png"}
					],
		--> when the player is ready to showdown			
		pCardsSorted:{ hF:{hand:[...], type:'One Pair', value:1, subvalue:1141404},
					   hM:{hand:[...], type:'Straight', value:4, subvalue:40908070605},	
					   hL:{hand:[...], type:'Straight Flush',	value:8, subvalue:40908070605}	
					 }
  }	
*/
  @Output() backToMenu = new EventEmitter<any>();
  potentialPlayers:[];
  playingPlayers:[];
  resultsNow:boolean;
  sd:any;
  
  ngOnInit() {
	this.resultsNow = false;
	this.gameLoad = false;
	this.potentialPlayers = [{pHere:false},{pHere:false},{pHere:false}];
	this.socketService.joinRoom(this.player);	
	this.socketService.playersUpdate().subscribe(opponents => {
		var tempOpp = opponents.filter( opp => opp.pId !== this.player.pId);
		if (this.gameLoad == false) {
			this.potentialPlayers = [{pHere:false},{pHere:false},{pHere:false}];
			for (var _p=0; _p< tempOpp.length; _p++) {
				this.potentialPlayers[_p] = tempOpp[_p];
				this.potentialPlayers[_p]['pHere'] = true;
			}
		}
		if (this.gameLoad == true) {
			for (var _p=0; _p< tempOpp.length; _p++) {
				var indexOpp = tempOpp.findIndex( opp => opp.pId == this.playingPlayers[_p].pId);
				if (indexOpp == -1) {
					this.playingPlayers[_p]['pHere'] = false; 
				}
				else {
					this.playingPlayers[_p] = opp[indexOpp];
				}
			}
		}
	});
	this.socketService.realPlayersUpdate().subscribe(realPlayers => {
		this.playingPlayers = realPlayers.filter( player => player.pID !== this.player.pId);
	});	
	this.socketService.cardsDealt().subscribe(cards => {
		this.player.pCardsDealt = this.cardService.imageCards(cards);
		this.gameLoad = true;
	});
	this.socketService.showResults().subscribe(sdComplete => {
		this.sd = sdComplete;
		this.gameLoad = false;
		this.resultsNow = true; 
	});
  }
  
  leftRoom() {
	if (!this.gameLoad) this.socketService.leaveBeforeGameStart(this.player);
	if (this.gameLoad) this.socketService.leaveAfterGameStart(this.player);
	this.backToMenu.emit();
  }
    
  humanPlayerReady(handFinal) {
	this.player.pCardsSorted = handFinal;
	this.socketService.playerSD(this.player);
  }
  
  endGame() {
    this.backToMenu.emit();
  }
}

}
