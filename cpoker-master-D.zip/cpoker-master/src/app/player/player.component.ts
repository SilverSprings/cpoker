import { Component, Input, OnInit, EventEmitter, Output  } from '@angular/core';
import { RankerService } from '../ranker.service';

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {

  @Output() doneSorting = new EventEmitter<any>();
  
  @Input() player:any; /* what player looks like : 
  {
		pId:'PLAYER_HUMAN',
		pRoom:'BOTROOM',
		pName:'Brandon',
		pSD:false,
		pCardsDealt:[{s:"d",v:10,img:"assets/10D.png"},
					 {s:"s",v:12,img:"assets/12S.png"},
					 {s:"d",v:8,img:"assets/8D.png"},
					 {s:"h",v:8,img:"assets/8H.png"},
					 {s:"h",v:2,img:"assets/2H.png"},
					 ...
					 {s:"d",v:7,img:"assets/7D.png"}] 
  }  
  */    
  //handPlayed hold the reference of the cards that the player has placed.  
  fh_played = {hand:[],type:'',value:0,subvalue:0};
  mh_played = {hand:[],type:'',value:0,subvalue:0};
  lh_played = {hand:[],type:'',value:0,subvalue:0}; 
  handDealt = [];

  counterCardsSelected:int;
  //messages for each hand
  fh_msg:string;
  mh_msg:string;
  lh_msg:string;
  
  favail:boolean;
  
  handFinal = {hF:{},hM:{},hL:{}};
  /*{
	 hF:{hand:[...], type:'One Pair', value:1, subvalue:1141404},
	 hM:{hand:[...], type:'Straight', value:4, subvalue:40908070605},	
	 hL:{hand:[...], type:'Straight Flush',	value:8, subvalue:40908070605}	
    } */  
  //disabled the evaluate button
  disableButton:boolean;

  constructor(private rankerService: RankerService) { }

  ngOnInit() {
	console.log('hand dealt to the player', this.player.pCardsDealt);	
	this.handDealt = this.player.pCardsDealt.map( c => {
		c['selected'] = false;
		return c;
	}
	this.fh_msg='';
	this.mh_msg='';
	this.lh_msg='';
	this.disableButton = true;	
	this.counterCardsSelected = 0;	
	this.fnotAvail=true;
	this.mnotAvail=true;
	this.lnotAvail=true;	
  }
  
  sortRank() {
	this.handDealt.sort( (a, b) => {return a.v - b.v});
  }
  
  sortSuit() {
	this.handDealt.sort( (a, b) => {return a.v - b.v});
	this.handDealt.sort( (a, b) => {
		if (a.s < b.s) return -1;
		if (a.s > b.s) return 1;
		if (a.s = b.s) return 0; 
	});
  }
  
  cardClickedHD(card, i) {
	if (this.counterCardsSelected <=5) {
		this.fnotAvail=true;
		this.mnotAvail=true;
		this.lnotAvail=true;	
		if (this.handDealt[i].selected == false) {
			if (this.counterCardsSelected != 5) {
				this.handDealt[i].selected = true;
				this.counterCardsSelected++;
			}
		} else {
			this.handDealt[i].selected = false;
			this.counterCardsSelected--;
		}
		if (this.counterCardsSelected != 0) {
			if (this.fh_played.hand.length==0 && counterCardsSelected <= 3) this.fnotAvail = false;
			if (this.fh_played.hand.length==1 && counterCardsSelected <= 2) this.fnotAvail = false;
			if (this.fh_played.hand.length==2 && counterCardsSelected == 1) this.fnotAvail = false;	

			if (this.mh_played.hand.length==0 && counterCardsSelected <= 5) this.mnotAvail = false;
			if (this.mh_played.hand.length==1 && counterCardsSelected <= 4) this.mnotAvail = false;
			if (this.mh_played.hand.length==2 && counterCardsSelected <= 3) this.mnotAvail = false;
			if (this.mh_played.hand.length==3 && counterCardsSelected <= 2) this.mnotAvail = false;
			if (this.mh_played.hand.length==4 && counterCardsSelected == 1) this.mnotAvail = false;

			if (this.lh_played.hand.length==0 && counterCardsSelected <= 5) this.lnotAvail = false;
			if (this.lh_played.hand.length==1 && counterCardsSelected <= 4) this.lnotAvail = false;
			if (this.lh_played.hand.length==2 && counterCardsSelected <= 3) this.lnotAvail = false;
			if (this.lh_played.hand.length==3 && counterCardsSelected <= 2) this.lnotAvail = false;
			if (this.lh_played.hand.length==4 && counterCardsSelected == 1) this.lnotAvail = false;
		}
	}
  }
  
  feed(handToFeed) {
	if (handToFeed == 'DH_FH') {
		this.fh_played.hand = this.fh_played.hand.concat(this.handDealt.filter(c => c.selected == true));
		this.handDealt = this.handDealt.filter(c => c.selected == false);
		if (this.fh_played.hand.length == 3) {
			var tempRes = checkHand(this.fh_played.hand, 3);
			this.fh_played.type = tempRes.type; 
			this.fh_played.value = tempRes.val;
			this.fh_played.subvalue = tempRes.subval;
			this.fh_msg = '' + tempRes.type;
		}
	}
	if (handToFeed == 'DH_MH') {
		this.mh_played.hand = this.mh_played.hand.concat(this.handDealt.filter(c => c.selected == true));
		this.handDealt = this.handDealt.filter(c => c.selected == false);	
		if (this.mh_played.hand.length == 5) {
			var tempRes = checkHand(this.mh_played.hand, 5);
			this.mh_played.type = tempRes.type; 
			this.mh_played.value = tempRes.val;
			this.mh_played.subvalue = tempRes.subval;
			this.mh_msg = '' + tempRes.type;	
		}
	}
	if (handToFeed == 'DH_LH') {
		this.lh_played.hand = this.lh_played.hand.concat(this.handDealt.filter(c => c.selected == true));
		this.handDealt = this.handDealt.filter(c => c.selected == false);		
		if (this.lh_played.hand.length == 5) {			
			var tempRes = checkHand(this.lh_played.hand, 5);
			this.lh_played.type = tempRes.type; 
			this.lh_played.value = tempRes.val;
			this.lh_played.subvalue = tempRes.subval;
			this.lh_msg = '' + tempRes.type;	
		}
	}
	this.disableButton = this.sdAvailable();
	this.evaluateMessage();
  }

  sdAvailable() {
	if (this.fh_played.hand.length == 3 && this.mh_played.hand.length == 5 && this.lh_played.hand.length == 5) {return false;} 
	else {return true;}
  }  

  evaluateMessage() {
	if (this.fh_played.hand.length == 3 && this.mh_played.hand.length == 5) {
		if (this.fh_played.subvalue > this.mh_played.subvalue) this.fh_msg = 'First hand better than Middle hand !';
	}
	if (this.mh_played.hand.length == 5 && this.lh_played.hand.length == 5) {
		if (this.mh_played.subvalue > this.lh_played.subvalue) this.mh_msg = 'Middle hand better than Last hand !';
	}	
  	if (this.fh_played.hand.length < 3) this.fh_msg = '';
	if (this.lh_played.hand.length < 5) this.lh_msg = '';
	if (this.mh_played.hand.length < 5) this.mh_msg = '';
  }
  
  showdown () {
	// emit the event with the final hand
	this.handFinal.hF = this.fh_played;
	this.handFinal.hM = this.mh_played;
	this.handFinal.hL = this.lh_played;
	this.doneSorting.emit(this.handFinal);
  } 
  
  cardClickedRemove(handToDelete, card, i) {
	card.selected = false;
	this.handDealt.push(card);
	if (handToDelete == 'FH') {
		this.fh_played.hand.splice(i,1);
	}
	if (handToDelete == 'MH') {
		this.mh_played.hand.splice(i,1);
	}
	if (handToDelete == 'LH') {
		this.lh_played.hand.splice(i,1);
	}
	this.disableButton = this.sdAvailable();
	this.evaluateMessage();	
  }
}

  function checkHand(handCk, cardsN) {
	console.log ('checkHand', hand, cardsN);
	if (handCk.length == cardsN) {
		var tempHandMini = handCk.map( card => {return {s:card.s, v:card.v};}) ;
		var tempHand = this.rankerService.bestHand(tempHandMini);
		return { type:tempHand.type, val:tempHand.val, subval:tempHand.subval} 		
	} else {return false;}
  }